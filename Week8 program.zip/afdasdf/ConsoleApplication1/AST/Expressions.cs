﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    // week 8 Bai
    public abstract class Expressions : Node
    {
    }

    public class Expression : Expressions
    {
        private AssignmentExpression assignmentExpression;
       /* public override void ResolvedName()
        {
            assignmentExpression.ResolvedName();
        }*/
        public Expression(AssignmentExpression assignmentExpression)
        {
            this.assignmentExpression = assignmentExpression;
        }
        public override void dump(int indent)
        {
            label(indent, "Expression:\n");
            assignmentExpression.dump(indent+1);
           
        }
    }
   
    public class AssignmentExpression : Expressions
    {
        private Literal literal;
       /* public override void ResolvedName()
        {
            literal.ResolvedName();
        }*/
        public AssignmentExpression(Literal literal)
        {
            this.literal = literal;
        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentExpression:\n");
            literal.dump(indent+1);
           
        }

    }

    public class Literal : Expressions
    {
        string num;
       /* public override void ResolvedName()
        {

        }*/
        public Literal(string num)
        {
            this.num = num;
        }
    
        public override void dump(int indent)
        {
            label(indent, "Literal : {0}\n", num);
           
        }
    }


    public class DecimalIntegerLiteral : Expressions
    {
        /*public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "DecimalIntegerLiteral:\n");
        }
    }
    public class HexIntegerLiteral : Expressions
    {
        /*public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "HexIntegerLiteral:\n");
        }
    }

  

}
