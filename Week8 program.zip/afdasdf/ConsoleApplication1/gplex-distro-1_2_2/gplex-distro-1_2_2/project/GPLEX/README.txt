
README file for GPLEX\GPLEX

Question:  What is different about GplexBuffers.cs, Parser.cs and Scanner.cs?

Answer:  
These three files are not part of the Source-Controlled distribution. 
These files are produced from specifications prior to the build, from gppg.lex, gppg.y, 
and the embedded resources of gplex.

Running the GenerateAll.bat batch file in ..\SpecFiles will restore these files.

Of course, you must have current versions of gppg.exe and gplex.exe on your executable
path to do this.

 
