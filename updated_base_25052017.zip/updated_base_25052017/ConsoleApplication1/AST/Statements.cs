﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace AST
{
    
    // week 8 Bai start
    public  class Statements : Node {
       /* NamedType namedtype;
        
        public NamedType get_namedtype()
        {
            return namedtype;
        }*/
        public override void dump(int indent)
        {
           
        }
        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {
           
        }
        public override void gecode(StreamWriter st)
        {
            
        }
    }
    
    public class ExpressionStatement : Statements
    {
        private Expression exp;
        public override void ResolvedName(Scope scope)
        {
            exp.ResolvedName(scope);
        }     
        public ExpressionStatement(Expression exp)
        {
            this.exp = exp;
        }

        public override void dump(int indent)
        {
            label(indent, "Statement:\n");
            exp.dump(indent + 1);
        }

        public override void TypeCheck()
        {
            exp.TypeCheck();
        }
        public override void gecode(StreamWriter st)
        {
            exp.gecode(st);
            st.WriteLine("pop");
        }
    }
   
    public class LocalVariableDeclarationstatement : Statements, IDeclaration
    {
        static int LastLocal = 0;

        private NamedType type; //int
        //private IdentifierExpression identifier; //x
        string identifier;
        private int num;

        public LocalVariableDeclarationstatement(NamedType type, string identifier)
        {
            num = LastLocal++;
            this.type = type;
            this.identifier = identifier;
           

        }
        public string get_name()
        {
            return identifier;
        }
        public override void ResolvedName(Scope scope)
        {
            type.ResolvedName(scope);
           
        }
       
        public override void dump(int indent)
        {
            label(indent, "LocalVariableDeclarationstatement:\n");
            type.dump(indent + 1);
            label(indent+1,"{0}\n", identifier);
        }
        public NamedType get_type()
        {
            return type;
        }
     
        public override void TypeCheck()
        {
            type.TypeCheck();
     
        }

        public override void gecode(StreamWriter st)
        {
            emit(st, ".locals init ([{0}] {1} {2})", num, type.get_name(), identifier);
        }
    }


    public class MethodBody : Statements
    {
        private List<Statements>  statements;

        public override void ResolvedName(Scope scope)
        {
            foreach (var stmt in statements)
                if (stmt is IDeclaration)
                {
                    IDeclaration decl = (IDeclaration)stmt;

                    scope.AddSymbol(decl.get_name(), decl); 
                }

            foreach (var stmt in statements)
                stmt.ResolvedName(scope);
        }  

        public MethodBody(List<Statements> statements)
        {         
            this.statements = statements;          
        }
        public override void dump(int indent)
        {
            label(indent,"Block");
            foreach (var a in statements)
            {
                a.dump(indent);
            }

        }
        public override void TypeCheck()
        {
            foreach (var a in statements)
            {
                a.TypeCheck(); 
            }
        }
        public override void gecode(StreamWriter st)
        {
            foreach (var a in statements)
            {
                a.gecode(st);
            }
            
        }
    }
 

    public class MethodHeader : Statements
    {
        private MethodDeclarator methodDecalrator;
        private Result result;

        public string get_name()
        {
            return methodDecalrator.get_name();
        }
        public override void ResolvedName(Scope scope)
        {
            methodDecalrator.ResolvedName(scope);
            result.ResolvedName(scope);
        }
        public MethodHeader(Result result, MethodDeclarator methodDecalrator)
        {
            this.methodDecalrator = methodDecalrator;
            this.result = result;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodHeader:\n");
            methodDecalrator.dump(indent+1);
            result.dump(indent+1);
        }
        public override void TypeCheck()
        {
            methodDecalrator.TypeCheck();
            result.TypeCheck();
        }
        public override void gecode(StreamWriter st)
        {
            methodDecalrator.gecode(st);
            result.gecode(st);
        }
    }


    public class Dims : Statements
    {
        private char left;
        private char right;
        public override void ResolvedName(Scope scope)
        {
   
        }
        public Dims()
        { }
        public Dims(char left, char right)
        {
            this.left = left;
            this.right = right;
        }

        public override void dump(int indent)
        {
            label(indent, "Dims:\n");
        }
        public override void TypeCheck()
        {

        }
        public override void gecode(StreamWriter st)
        {

        }
    }
   
  
}
