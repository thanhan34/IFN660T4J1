﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public class Scope
    {
        protected Scope parentScope;
        Dictionary<string, AST.Declaration> symbol_table;
        public Scope()
        {
            parentScope = null;
            symbol_table.Clear();
        }
      
    }
}
