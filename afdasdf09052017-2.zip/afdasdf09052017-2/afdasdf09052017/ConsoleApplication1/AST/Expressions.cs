﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    // week 8 Bai
    public abstract class Expressions: Node
    {
        public Type type;
    }

   /* public class Expression : Expressions
    {
        private AssignmentExpression assignmentExpression;
        public override bool ResolvedName(Scope scope)
        {
            return assignmentExpression.ResolvedName(scope);
        }
        public Expression(AssignmentExpression assignmentExpression)
        {
            this.assignmentExpression = assignmentExpression;
        }
        public override void dump(int indent)
        {
            label(indent, "Expression:\n");
            assignmentExpression.dump(indent+1);
           
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }*/
   
    public class AssignmentExpression : Expressions
    {
       // private Literal literal;
        private Expressions lhs, rhs;
        public override bool ResolvedName(Scope scope)
        {
            return lhs.ResolvedName(scope)&&rhs.ResolvedName(scope);
        }
        public AssignmentExpression( Expressions lhs, Expressions rhs)
        {
            this.lhs = lhs;
            this.rhs = rhs;


        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentExpression:\n");
            //literal.dump(indent+1);
            type.dump(indent + 1, "type");
            lhs.dump(indent + 1, "lhs");
            rhs.dump(indent + 1, "rhs");
           
        }

        public override void TypeCheck()
        {
            lhs.TypeCheck();
            rhs.TypeCheck();
            if (!rhs.type.Compatible(lhs.type))
            {
                Console.WriteLine("type error in assignment\n");
                throw new Exception("TypeCheck error");
            }
            type = rhs.type;
        }
    }

    public class Literal : Expressions
    {
        private string num;
        private Declaration declaration;

        public override bool ResolvedName(Scope scope)
        {
            if(scope!=null)
                declaration=scope.R
        }
        public Literal(string num, Expressions lhs, Expressions rhs)
        {
            this.num = num;
            this.lhs = lhs;
            this.rhs = rhs;
        }
    
        public override void dump(int indent)
        {
            if (declaration != null)
                label(indent, "Literal : {0}\n", num, declaration);
            else
                label(indent, "Literal: {0}\n", num);
            type.dump(indent + 1, "type");

           
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }


    public class DecimalIntegerLiteral : Expressions
    {
        public override bool ResolvedName(Scope scope)
        {
            return true;
        }
        public override void dump(int indent)
        {
            label(indent, "DecimalIntegerLiteral:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class HexIntegerLiteral : Expressions
    {
        public override bool ResolvedName(Scope scope)
        {
            return true;
        }
        public override void dump(int indent)
        {
            label(indent, "HexIntegerLiteral:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

  

}
