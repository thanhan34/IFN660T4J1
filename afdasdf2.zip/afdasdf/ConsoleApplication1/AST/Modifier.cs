﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AST
{
    public abstract class Modifier: Node
    {
        public override void ResolvedName(Scope scope)
        {

        }
    }
    public class Public : Modifier
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "PublicModifier:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class Static : Modifier
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "StaticModifier:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
   
    public class ClassModifier : Modifier
    {
        private string Public;
        public ClassModifier(string Public)
        {
            this.Public = Public;
        }
        public override void dump(int indent)
        {
            label(indent, "{0}\n",Public);
        }

        public override void ResolvedName(Scope scope)
        {
           
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
      public class MethodModifier : Modifier
     {
        private string Public;
        private string Static;
        public override void ResolvedName(Scope scope)
        {
            
        }
        public MethodModifier( string Public,  string Static)
         {
            this.Public = Public;
            this.Static = Static;
         }
    /*    public MethodModifier(Public Public)
        {
            this.Public = Public;
           
        }
        public MethodModifier(Static Static)
        {           
            this.Static = Static;
        }
        public MethodModifier()
        {

        } */
        public override void dump(int indent)
         {
            label(indent, "MethodModifier: {0} {1}\n",Public,Static);
         }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
     
}
