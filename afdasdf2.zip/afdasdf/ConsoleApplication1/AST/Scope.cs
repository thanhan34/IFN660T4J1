﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public class Scope
    {
        protected Scope parentScope;
        Dictionary<string, AST.Declaration> symbol_table;
        public Scope(Scope parentScope)
        {
            this.parentScope = parentScope;
            symbol_table.Clear();
        }
        Declaration ResolveHere(string symbol)
        {
            if (symbol_table.ContainsKey(symbol))
            {
                return symbol_table[symbol];
            }
            else
            {
                return null;

            }
        }
        Declaration Resolve(string symbol)
        {
            Declaration local = ResolveHere(symbol);
            if (local != null)
            {
            }
        }
        public void AddSymbol(string name,Declaration declaration)
        {
            this.symbol_table.Add(name, declaration);
        }
    }
}
