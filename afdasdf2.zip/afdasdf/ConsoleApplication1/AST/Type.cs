﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public  class Type : Node {
        public override void ResolvedName(Scope scope)
        {
            
        }
        
        public bool Compatible(Type type)
        {
            return Equal(type);
        }

        bool Equal(Type type) {
            return true;
        }
        public override void dump(int indent)
        {
            
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class Result : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "Result:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class UnannType : Type
    {
        private UnannPrimitiveType unannPrimitiveType;
        private UnannReferenceType unannReferenceType;
        public override void ResolvedName(Scope scope)
        {
            unannPrimitiveType.ResolvedName(scope);
            unannReferenceType.ResolvedName(scope);
        }
        public UnannType(UnannPrimitiveType unannPrimitiveType)
        {
            this.unannPrimitiveType = unannPrimitiveType;
           
        }
        public UnannType(UnannReferenceType unannReferenceType)
        {
            
            this.unannReferenceType = unannReferenceType;
        }
        public override void dump(int indent)
        {
            label(indent, "UnannType:\n");
            if (unannPrimitiveType != null)
            {
                unannPrimitiveType.dump(indent + 1);
            }
            else if (unannReferenceType != null)
            {
                unannReferenceType.dump(indent + 1);
            }
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class UnannPrimitiveType : Type
    {
        private NumericType numericType;
        private string boolean;
        public override void ResolvedName(Scope scope)
        {
            numericType.ResolvedName(scope);
        }
        //boolean numeric
        public UnannPrimitiveType(NumericType numericType)
        {
            this.numericType = numericType;
        }
        public UnannPrimitiveType(string boolean)
        {
            this.boolean = boolean;
        }
        public override void dump(int indent)
        {
            numericType.dump(indent + 1, "numericType:\n");
            
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }

    }

    // week8 Bai
    public class NumericType : Type
    {
        private IntegralType inter;
        private FloatingPointType floatpoint;
        public override void ResolvedName(Scope scope)
        {
            inter.ResolvedName();
            floatpoint.ResolvedName();
        }
        public NumericType(IntegralType inter)
        {
            this.inter = inter;
        }
        public NumericType(FloatingPointType floatpoint)
        {
            this.floatpoint = floatpoint;
        }
        public override void dump(int indent)
        {
            label(indent, "NumericType:\n");
            if (inter != null)
            {
                inter.dump(indent);
            }
            else if (floatpoint != null)
            {
                floatpoint.dump(indent);
            }
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class ByteType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ByteType\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class ShortType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ShortType\n");
            
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class LongType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "LongType\n");

        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class CharType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "CharType\n");

        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class InteType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "IntType\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class IntegralType : Type
    {
        public string inttype;
        public override void ResolvedName(Scope scope)
        {

        }
        public IntegralType(string inttype) {

            this.inttype = inttype;

        }
        public override void dump(int indent)
        {
            label(indent, "IntegralType : {0}\n", inttype);
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class FloatingPointType : Type
    {
        private string floattype;
        public override void ResolvedName(Scope scope)
        {

        }
        public FloatingPointType(string floattype) {
            this.floattype = floattype;
        }
        public override void dump(int indent)
        {
            label(indent, "FloatingPointType : {0}\n", floattype);
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class FloatType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "FloatType\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class DoubleType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "DoubleType\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class UnannReferenceType : Type
    {
        private UnannArrayType unannArrayType;
        public override void ResolvedName(Scope scope)
        {
            unannArrayType.ResolvedName();
        }

        public UnannReferenceType(UnannArrayType unannArrayType)
        {
            this.unannArrayType = unannArrayType;
        }
        public override void dump(int indent)
        {
            label(indent, "UnannReferenceType:\n");
            unannArrayType.dump(indent+1);
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class UnannArrayType : Type
    {
        private UnClassOrInterfaceType unClassOrInterfaceType;
        private Dims dims1;
        public override void ResolvedName(Scope scope)
        {
            unClassOrInterfaceType.ResolvedName(scope);
            dims1.ResolvedName(scope);
        }
        public UnannArrayType(UnClassOrInterfaceType unClassOrInterfaceType, Dims dims1)
        {
            this.unClassOrInterfaceType = unClassOrInterfaceType;
            this.dims1 = dims1;
          

        }
        public override void dump(int indent)
        {
            label(indent+1,"unannarraytype:\n");
            unClassOrInterfaceType.dump(indent+1);
            dims1.dump(indent+1);
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class UnClassOrInterfaceType : Type
    {
        private UnClassType unClassType;
        public override void ResolvedName(Scope scope)
        {
            unClassType.ResolvedName(scope);
        }
        public UnClassOrInterfaceType (UnClassType unClassType)
        {
            this.unClassType = unClassType;
        }
        public override void dump(int indent)
        {
            label(indent + 1, "UnClassOrInterfaceType:\n");
            unClassType.dump(indent+1);
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class UnClassType : Type
    {
        private string STRING;
        public override void ResolvedName(Scope scope)
        {

        }
        public UnClassType (string STRING)
        {
            this.STRING = STRING;
        }

        public override void dump(int indent)
        {
            label(indent + 1, "UnClassType : {0}\n", STRING);

        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class UnannTypeVariable : Type
    {
        private Identifier identifier;
        public override void ResolvedName(Scope scope)
        {

        }
        public UnannTypeVariable (Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent + 1, "UnannTypeVariable:\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

      public class NamedType : Type
      {
          private string typeName;
        public override void ResolvedName(Scope scope)
        {

        }
        public NamedType(string typeName)
        {
              this.typeName = typeName;
        }
        public override void dump(int indent)
        {
              label(indent, "NamedType:\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
      public class ArrayType : Type
      {
          private Type elementType;
        public override void ResolvedName(Scope scope)
        {

        }
        public ArrayType(Type elementType)
        {
            this.elementType = elementType;
        }
        public override void dump(int indent)
        {
            label(indent, "elementType:\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }


      public class ReturnType : Type
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ReturnType\n");
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }

    }
      public class VoidType : Result
      {
        public override void ResolvedName(Scope scope)
        {

        }

        public override void dump(int indent)
          {
              label(indent, "VoidType\n");
          }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }

    }



    public class IntType : Result
     {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
         {
             label(indent, "IntType\n");
         }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }

    }



}
