﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    class Declare
    {
        public virtual Type GetType() {
            return null;
        }
        public virtual string GetName() {
            return null;
        }
    }
}
