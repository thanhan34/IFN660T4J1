﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public abstract class Declaration : Node
    {
    }
    public class PackageDeclaration_Opt : Declaration
    {

        public PackageDeclaration_Opt()
        {
            
        }
        public override void dump(int indent)
        {
            label(indent, "PackageDeclaration_Opt\n");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class ImportDeclaration : Declaration
    {
        public ImportDeclaration()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ImportDeclaration\n");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public  class TypeDeclaration : Declaration
    {
        public override void dump(int indent)
        {
            label(indent, "TypeDeclaration\n");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class LocalVariableDeclaration : Declaration
    {
        private UnannType unannType;
        public VariableDeclarator variableDeclartor;
        public LocalVariableDeclaration(UnannType unannType, VariableDeclarator variableDeclartor)
            {
            this.unannType = unannType;
            this.variableDeclartor = variableDeclartor;
            }
        public override void dump(int indent)
        {
            label(indent, "LocalVariableDeclaration\n");
            unannType.dump(indent+1, "UnannType");
            variableDeclartor.dump(indent+1, "VariableDeclarator");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class VariableDeclarator : Declaration
    {
        public Identifier identifier;
        public VariableDeclarator(Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent, "VariableDeclarator\n");
            identifier.dump(indent+1, "Identifier");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class NormalClassDeclaration : TypeDeclaration
    {
        private ClassModifier classModifier;
        private Identifier identifier;//HelloWrold
        private TypeParameters_opt typeParameters_opt;
        private SuperClass_opt superClass_opt;
        private SuperInterfaces_opt superInterfaces_opt;
        private ClassBody classBody;
       // private List<Modifier> classModifier;   
        //private List<MethodDeclaration> methodDeclaration;  
        // "class"?

        public NormalClassDeclaration(ClassModifier classModifier, Identifier identifier, TypeParameters_opt typeParameters_opt, 
            SuperClass_opt superClass_opt, SuperInterfaces_opt superInterfaces_opt, ClassBody classBody)
        {
          
            this.classModifier = classModifier;
            this.identifier = identifier;
            this.typeParameters_opt = typeParameters_opt;
            this.superClass_opt = superClass_opt;
            this.superInterfaces_opt = superInterfaces_opt;
            this.classBody = classBody;
        }
        
        public override void dump(int indent)
        {
            label(indent, "NormalClassDeclaration:\n");
            classModifier.dump(indent+1);
            identifier.dump(indent+1);
            typeParameters_opt.dump(indent+1);
            superClass_opt.dump(indent+1);
            superInterfaces_opt.dump(indent+1);
            classBody.dump(indent+1);
            
            /*foreach (var child in classModifier)
                child.dump(indent + 1);
            foreach (var child in methodDeclaration)
                child.dump(indent + 1); */
        }

        
    }
    public class MethodDeclarator : Declaration
    {
        private Identifier identifier;
        private FormalParameterList formalParameterList;
       // private Dims dims;
        public MethodDeclarator(Identifier identifier, FormalParameterList formalParameterList)
        {
            this.identifier = identifier;
            this.formalParameterList = formalParameterList;
           // this.dims = dims;
        }
        public override void dump(int indent)
        {
            label(indent, "NormalClassDeclaration:\n");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class MethodDeclaration : Declaration
    {      
        private MethodModifier methodModifier; //public   
        private MethodHeader methodHeader;
        private MethodBody methodBody;
        public MethodDeclaration(MethodModifier methodModifier, MethodHeader methodHeader, MethodBody methodBody)
        {
            this.methodModifier = methodModifier;
            this.methodHeader = methodHeader;
            this.methodBody = methodBody;
        }    
        public override void dump(int indent)
        {
            label(indent, "MethodDeclaration:\n");
            methodModifier.dump(indent+1);
            methodHeader.dump(indent+1);
            methodBody.dump(indent+1);
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }  
    public class Identifier : Node
    {
        public string ident;
        public override void ResolvedName(Scope scope)
        {

        }
        public Identifier(string ident)
        {
            this.ident = ident;
        }
        public override void dump(int indent)
        {
            label(indent, "{0}\n",ident);
            
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class IdentifierChars : Node
    {
        private JavaLetter javaLetter;
        public JavaLetterOrDigits javaLetterOrDigits;
        public override void ResolvedName(Scope scope)
        {
            javaLetter.ResolvedName(scope);
            javaLetterOrDigits.ResolvedName(scope);
        }
        public IdentifierChars(JavaLetter javaLetter, JavaLetterOrDigits javaLetterOrDigits)
        {
            this.javaLetter = javaLetter;
            this.javaLetterOrDigits = javaLetterOrDigits;
        }
        
        public override void dump(int indent)
        {
            label(indent, "IdentifierChars\n");
        }

       /* public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }*/

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class JavaLetter : Node
    {
        private IDENT iDENT;
        public override void ResolvedName(Scope scope)
        {
            iDENT.ResolvedName(scope);
        }
        public JavaLetter(IDENT iDENT)
        {
            this.iDENT = iDENT;
        }
        public override void dump(int indent)
        {
            label(indent, "JavaLetter:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class JavaLetterOrDigits : Node
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "JavaLetterOrDigits:\n");
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class IDENT : Node
    {
        private string iDENT;
        public override void ResolvedName(Scope scope)
        {

        }
        public IDENT(string iDENT)
        {
            this.iDENT = iDENT;
        }
        public override void dump(int indent)
        {
            label(indent, "IDENT: {0}\n", iDENT);
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    //frank 10/04

    public class ClassBody : Declaration
    {
        private ClassBodyDeclaration classBodyDeclaration;
        public ClassBody(ClassBodyDeclaration classBodyDeclaration)
        {
            this.classBodyDeclaration = classBodyDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent,"ClassBosy:\n");
            classBodyDeclaration.dump(indent+1);
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }


    public class ClassBodyDeclaration : Declaration
    {
        private MethodDeclaration methodDeclaration;
        public ClassBodyDeclaration(MethodDeclaration methodDeclaration)
        {
            this.methodDeclaration = methodDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "ClassBodyDeclaration:\n");
            methodDeclaration.dump(indent+1);
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class ClassMemberDeclaration : Declaration
    {
        private MethodDeclaration methodDeclaration;
        public ClassMemberDeclaration(MethodDeclaration methodDeclaration)
        {
            this.methodDeclaration = methodDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "ClassMemberDeclaration\n");
        }

        public override void ResolvedName(Scope scope)
        {
            throw new NotImplementedException();
        }

        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
 

    //frank 10/04
}
