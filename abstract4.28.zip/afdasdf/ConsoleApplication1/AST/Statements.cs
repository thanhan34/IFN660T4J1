﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{

    // week 8 Bai start
    public abstract class Statements : Node { }
    public class Statement : Statements
    {
        private Assignment ass;

        public Statement(Assignment ass)
        {
            this.ass = ass;
        }
        public override void dump(int indent)
        {
            //label(indent, "Statement\n");
            ass.dump(indent + 1, "Statement");
        }
    }

    public class Assignment : Statements
    {
        private LeftHandSide leftHandSide;
        private AssignmentOperator assignmentOperator;
        private Expression expression;

        public Assignment(LeftHandSide leftHandSide, AssignmentOperator assignmentOperator, Expression expression)
        {
            this.leftHandSide = leftHandSide;
            this.assignmentOperator = assignmentOperator;
            this.expression = expression;
        }
        public override void dump(int indent)
        {
            label(indent, "Assignment");
            leftHandSide.dump(indent + 1,"LefthandSide");
            assignmentOperator.dump(indent + 1, "assignmentOperator");
            expression.dump(indent + 1, "expression");
            
        }
    }

    public class AssignmentOperator : Statements
    {
        private string assignmentOperator;

        public AssignmentOperator(string assignmentOperator)
        {
            this.assignmentOperator = assignmentOperator;
        }
        public override void dump(int indent)
        {
            label(indent, "Assignment");
        }
    }

    public class LeftHandSide : Statements
    {
        public override void dump(int indent)
        {
            label(indent, "LeftHandSide");
            
        }
    }
    public class Ident : LeftHandSide
    {
        private string ident;

        public Ident(string ident)
        {
            this.ident = ident;
        }
        public override void dump(int indent)
        {
            label(indent, "ident\n");
        }
    }
    //week 8 Bai end

    public class MethodBody : Statements
    {
        private Block block;
        /*public override void ResolvedName() {
            blockStatement.ResolvedName();
        }  */

        public MethodBody(Block block)
        {
            this.block = block;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodBody");
        }
    }
 
    public class Block : Statements
    {
        private LocalVariableDeclaration localVariableDeclaration;

        public Block(LocalVariableDeclaration localVariableDeclaration)
        {
            this.localVariableDeclaration = localVariableDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "Block");
        }
    }
 
    public class LocalVariableDeclarationstatement : Statements
    {
        private NamedType type; //int
        private string identifier; //x
        public LocalVariableDeclarationstatement(NamedType type, string identifier)
        {
            this.type = type;
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent, "BlockStatement\n", identifier);
            type.dump(indent + 1);
        }
    }

    public class ExpressionStatement : Statements
    {
        public ExpressionStatement()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ExpressionStatement\n");
        }
    }
    /*
    public class AssignmentExpression : ExpressionStatement
    {
        private VariableInitializer variableinitializer;
        public AssignmentExpression(VariableInitializer variableinitializer)
        {
            this.variableinitializer = variableinitializer;
        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentStatement\n");
            variableinitializer.dump(indent + 1);
        }
    }*/
    public class MethodHeader : Statements
    {
        private MethodDeclarator methodDecalrator;
        private Result result;
        public MethodHeader(Result result, MethodDeclarator methodDecalrator)
        {
            this.methodDecalrator = methodDecalrator;
            this.result = result;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodHeader");
        }
    }
    public class Dims : Statements
    {
        private char left;
        private char right;
        public Dims()
        { }
        public Dims(char left, char right)
        {
            this.left = left;
            this.right = right;
        }

        public override void dump(int indent)
        {
            label(indent, "Dims");
        }
    }
  
}
