﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    // week 8 Bai
    public abstract class Expressions : Node
    {
    }

    public class Expression : Expressions
    {
        private AssignmentExpression assignmentExpression;
        public Expression(AssignmentExpression assignmentExpression)
        {
            this.assignmentExpression = assignmentExpression;
        }
        public override void dump(int indent)
        {
            label(indent, "Expression\n");
            assignmentExpression.dump(indent + 1);
        }
    }
   
    public class AssignmentExpression : Expressions
    {
        private Literal literal;
        public AssignmentExpression(Literal literal)
        {
            this.literal = literal;
        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentExpression\n");
            literal.dump(indent + 1);
        }

    }

    public class Literal : Expressions
    {
        public override void dump(int indent)
        {
            label(indent, "Literal\n");
           
        }
    }


    public class DecimalIntegerLiteral : Literal
    {
        public override void dump(int indent)
        {
            label(indent, "DecimalIntegerLiteral\n");
        }
    }
    public class HexIntegerLiteral : Literal
    {
        public override void dump(int indent)
        {
            label(indent, "HexIntegerLiteral\n");
        }
    }

  

}
