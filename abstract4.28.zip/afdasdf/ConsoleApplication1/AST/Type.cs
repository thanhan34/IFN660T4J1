﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public abstract class Type : Node { }
    public class Result : Type
    {
        public override void dump(int indent)
        {
            label(indent, "Result");
        }
    }
    public class UnannType : Type
    {
        private UnannPrimitiveType unannPrimitiveType;
        private UnannReferenceType unannReferenceType;
        public UnannType(UnannPrimitiveType unannPrimitiveType)
        {
            this.unannPrimitiveType = unannPrimitiveType;
           
        }
        public UnannType(UnannReferenceType unannReferenceType)
        {
            
            this.unannReferenceType = unannReferenceType;
        }
        public override void dump(int indent)
        {
            unannPrimitiveType.dump(indent + 1, "unannPrimitiveType");
            unannReferenceType.dump(indent + 1, "unannReferenceType");
        }
    }
    public class UnannPrimitiveType : Type
    {
        private NumericType numericType;
        private string boolean;
        //boolean numeric
        public UnannPrimitiveType(NumericType numericType)
        {
            this.numericType = numericType;
        }
        public UnannPrimitiveType(string boolean)
        {
            this.boolean = boolean;
        }
        public override void dump(int indent)
        {
            numericType.dump(indent + 1, "numericType");
            
        }
    
    }

    // week8 Bai
    public class NumericType : Type
    {
        private IntegralType integralType;
        private FloatingPointType floatingPointType;

        public NumericType(IntegralType integralType)
        {
            this.integralType = integralType;
        }
        public NumericType(FloatingPointType floatingPointType)
        {
            this.floatingPointType = floatingPointType;
        }
        public override void dump(int indent)
        {
            integralType.dump(indent + 1, "integralType");
            floatingPointType.dump(indent + 1, "floatingPointType");

        }
    }

    public class ByteType : IntegralType
    {
        public override void dump(int indent)
        {
            label(indent, "ByteType\n");
        }
    }

    public class ShortType : IntegralType
    {
        public override void dump(int indent)
        {
            label(indent, "ShortType\n");
            
        }
    }

    public class LongType : IntegralType
    {
        public override void dump(int indent)
        {
            label(indent, "LongType\n");

        }
    }

    public class CharType : IntegralType
    {
        public override void dump(int indent)
        {
            label(indent, "CharType\n");

        }
    }

    public class InteType : IntegralType
    {
        public override void dump(int indent)
        {
            label(indent, "IntType");
        }
    }
    public class IntegralType : Type
    {
        public override void dump(int indent)
        {
            label(indent, "IntegralType");
        }
    }

    public class FloatingPointType : Type
    {
        public override void dump(int indent)
        {
            label(indent, "FloatingPointType");
        }
    }

    public class FloatType : FloatingPointType
    {
        public override void dump(int indent)
        {
            label(indent, "FloatType");
        }
    }

    public class DoubleType : FloatingPointType
    {
        public override void dump(int indent)
        {
            label(indent, "DoubleType");
        }
    }

    public class UnannReferenceType : Type
    {
        private UnannArrayType unannArrayType;
    
        public UnannReferenceType(UnannArrayType unannArrayType)
        {
            this.unannArrayType = unannArrayType;
        }
        public override void dump(int indent)
        {
            unannArrayType.dump(indent, "UnannArrayType");
        }
    }
    public class UnannArrayType : Type
    {
        private UnClassOrInterfaceType unClassOrInterfaceType;
        private Dims dims1;
        private UnannTypeVariable unannTypeVariable;
        private Dims dims2;
        public UnannArrayType(UnClassOrInterfaceType unClassOrInterfaceType, Dims dims1, UnannTypeVariable unannTypeVariable, Dims dims2)
        {
            this.unClassOrInterfaceType = unClassOrInterfaceType;
            this.dims1 = dims1;
            this.unannTypeVariable = unannTypeVariable;
            this.dims2 = dims2;
        }
        public override void dump(int indent)
        {
            throw new NotImplementedException();
        }
    }

    public class UnClassOrInterfaceType : Type
    {
        private UnClassType unClassType;

        public UnClassOrInterfaceType (UnClassType unClassType)
        {
            this.unClassType = unClassType;
        }
        public override void dump(int indent)
        {
            throw new NotImplementedException();
        }
    }

    public class UnClassType : Type
    {
        private string STRING;

        public UnClassType (string STRING)
        {
            this.STRING = STRING;
        }

        public override void dump(int indent)
        {
            throw new NotImplementedException();
        }
    }

    public class UnannTypeVariable : Type
    {
        private Identifier identifier;

        public UnannTypeVariable (Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            throw new NotImplementedException();
        }
    }

      public class NamedType : Type
      {
          private string typeName;

          public NamedType(string typeName)
          {
              this.typeName = typeName;
          }
          public override void dump(int indent)
          {
              label(indent, "NamedType");
          }
      }
      public class ArrayType : Type
      {
          private Type elementType;

          public ArrayType(Type elementType)
          {
              this.elementType = elementType;
          }
          public override void dump(int indent)
          {
              label(indent, "elementType");
          }
      }


      public class ReturnType : Type
      {
          public override void dump(int indent)
          {
              label(indent, "ReturnType");
          }

      }
      public class VoidType : Result
      {
          
          public override void dump(int indent)
          {
              label(indent, "VoidType");
          }
      }

  
    
     public class IntType : Result
     {

         public override void dump(int indent)
         {
             label(indent, "IntType");
         }
     }
     

  
}
