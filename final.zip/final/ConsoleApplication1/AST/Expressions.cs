﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    // week 8 Bai
    public abstract class Expression : Node
    {
        protected IDeclaration declaration;
        public Type type;
       
        public IDeclaration get_IDeclaration()
        {
            return declaration;
        }
        public Type get_type()
        {
            return type;
        }

    }

    /* public class Expression : Expressions
     {
         private AssignmentExpression assignmentExpression;
         public override bool ResolvedName(Scope scope)
         {
             return assignmentExpression.ResolvedName(scope);
         }
         public Expression(AssignmentExpression assignmentExpression)
         {
             this.assignmentExpression = assignmentExpression;
         }
         public override void dump(int indent)
         {
             label(indent, "Expression:\n");
             assignmentExpression.dump(indent+1);

         }
         public override void TypeCheck()
         {
             throw new NotImplementedException();
         }
     }*/

    public class NumberExpression : Expression
    {
        string num;
        public NumberExpression(string num)
        {
            this.num = num;
        }
        public override void ResolvedName(Scope scope)
        {
            if (scope != null)
            {
                scope.Resolve(num);
               
            }
           else
            {
                Console.WriteLine("Error: Undeclared identifier {0}",num);

                throw new Exception();
            }
        }
        public override void dump(int indent)
        {
            label(indent, "NumberExpression : {0}\n", num );
        }
        public override void TypeCheck()
        {
            type = new InteType();
        }
        public override void gecode(StreamWriter st)
        {
            emit(st, "ldc.i4 " + num );
           
        }
    }

    public class IdentifierExpression : Expression
    {
        string id;
        public IDeclaration declaration;
        public IdentifierExpression(string id)
        {
            this.id = id;
        }
       
        public override void ResolvedName(Scope scope)
        {
            if (scope != null)
            {
                declaration = scope.Resolve(id);
                
            }
            if(declaration == null)
            {
                Console.WriteLine("Error: Undeclared identifier {0}", id);

                throw new Exception();
            }
        }
        public string get_name()
        {
            return id;
            
        }
        public override void dump(int indent)
        {
            label(indent, "IdentifierExpression : {0}\n", id);
        }
        public override void TypeCheck()
        {
            type = declaration.get_type().get_type();        
        }
        public override void gecode(StreamWriter st)
        {
            emit(st, "ldloc " + id);
        }
        public void gestorecode(StreamWriter st)
        {
            emit(st,"stloc " +id);
        }
    }

    public class AssignmentExpression : Expression
    {
        // private Literal literal;
        private Expression lhs, rhs;
        public override void ResolvedName(Scope scope)
        {
            lhs.ResolvedName(scope);
            rhs.ResolvedName(scope);
        }
        public AssignmentExpression(Expression lhs, Expression rhs)
        {
            this.lhs = lhs;
            this.rhs = rhs;
          
        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentExpression:\n");        
            lhs.dump(indent + 1);
            rhs.dump(indent + 1);

        }

        public override void TypeCheck()
        {
            lhs.TypeCheck();
            rhs.TypeCheck();
            if (!(lhs.type.Equal(rhs.type)))
            {
                Console.WriteLine("type error in assignment\n");
                throw new Exception("TypeCheck error");
            }
            type = rhs.type;
        }
        public override void gecode(StreamWriter st)
        {
            lhs.gecode(st);
            rhs.gecode(st);
        }
    }

   

    public class BinaryExpression : Expression
    {
        private Expression lhs, rhs;
        private char op;

        public BinaryExpression(Expression lhs, char op, Expression rhs)
        {
            this.lhs = lhs;
            this.op = op;
            this.rhs = rhs;

        }
        public override void ResolvedName(Scope scope)
        {
            lhs.ResolvedName(scope); rhs.ResolvedName(scope);
        }
        public override void dump(int indent)
        {
            label(indent, "DecimalIntegerLiteral:\n");
           
            lhs.dump(indent + 1 );
            rhs.dump(indent + 1 );
        }

        public override void TypeCheck()
        {
            lhs.TypeCheck();
            rhs.TypeCheck();

            switch (op)
            {
                
                case '<':
                    // if (!lhs.type.Equals(new IntType()) || !rhs.type.Equals(new IntType()))
                    if (!lhs.type.Equal(rhs.type))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        //throw new Exception("TypeCheck error");
                    }
                    //type = new NamedType("boolean");
                    type = new BoolType();
                    break;
                case '>':
                    // if (!lhs.type.Equals(new IntType()) || !rhs.type.Equals(new IntType()))
                    if (!lhs.type.Equal(rhs.type))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        throw new Exception("TypeCheck error");
                    }
                    type = new BoolType();
                    break;
                case '+':
                    // if (!lhs.type.Equals(new IntType()) || !rhs.type.Equals(new IntType()))
                    if (!lhs.type.Equal(rhs.type))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        throw new Exception("TypeCheck error");
                    }
                    type = new BoolType();
                    break;
                case '-':
                    if (!lhs.type.Equal(new IntType()) || !rhs.type.Equals(new IntType()))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        throw new Exception("TypeCheck error");
                    }
                    type = new BoolType();
                    break;
                case '*':
                    if (!lhs.type.Equals(new IntType()) || !rhs.type.Equals(new IntType()))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        throw new Exception("TypeCheck error");
                    }
                    type = new BoolType();
                    break;
                case '/':
                    if (!lhs.type.Equal(new IntType()) || !rhs.type.Equals(new IntType()))
                    {
                        System.Console.WriteLine("invalid arguments for less than expression\n");
                        throw new Exception("TypeCheck error");
                    }
                    type = new BoolType();
                    break;
                default:
                    {
                        System.Console.WriteLine("Unexpected binary operator\n" + op);
                    }
                    break;
            }

        }
        public override void gecode(StreamWriter st)
        {
            switch (op)
            {
                case '+': emit(st, "add");
                    break;
                case '-':
                    emit(st, "sub");
                    break;
                case '*':
                    emit(st, "mul");
                    break;
                case '/':
                    emit(st, "div");
                    break;
                case '>':
                    emit(st, "cgt");
                    break;
                case '<':
                    emit(st, "clt");
                    break;
                default:
                    break;
            }
        }
    }
    public class CharExpression : Expression
    {
        string a;
        public CharExpression(string a)
        {
            this.a = a;
        }
        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void dump(int indent)
        {
            label(indent, "CharExpression: {0}\n", a);
        }
        public override void TypeCheck()
        {
            type = new CharType();
        }
        public override void gecode(StreamWriter st)
        {
            emit(st, "ldc.i4 " + a);

        }
    }

    public class StringExpression : Expression
    {
        string a;
        public StringExpression(string a)
        {
            this.a = a;
        }
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "StringExpression: {0}\n", a);
        }
        public override void TypeCheck()
        {
            type = new StringType();
        }
        public override void gecode(StreamWriter st)
        {
            emit(st, "ldc.i4 " + a);

        }
    }
    public class BooleanExpression : Expression
    {
        string a;
        public BooleanExpression(string a)
        {
            this.a = a;
        }
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "BooleanExpression: {0}\n", a);
        }
        public override void TypeCheck()
        {
            type = new BoolType();
        }
        public override void gecode(StreamWriter st)
        {
            emit(st, "ldc.i4 " + a);

        }
    } 
}