﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
namespace AST
{
    public abstract class Node
    {
       
        public abstract void dump(int indent);
        public  void emit(StreamWriter st, string format, params object[] args)
        {
            st.WriteLine(String.Format(format, args));
        }
        
            
        
        //public abstract void emit

        //week7
        public abstract void ResolvedName(Scope scope);


        public abstract void  TypeCheck();
        private void indent(int N)
        {

            for (int i = 0; i < N; i++)
                Console.Write("    ");
        }

        protected void label(int i, string fmt, params object[] args)
        {
            indent(i);
            Console.Write(fmt, args);
        }

        public void dump(int i, string name)
        {
            label(i, "{0}:\n", name);
            dump(i + 1);
        }

        public abstract void gecode(StreamWriter st);
        
    }

    public class LexicalScope
    {
        protected LexicalScope parentScope;

    }
        /*public abstract class Node
        {
            void Indent(int n)
            {
                for (int i = 0; i < n; i++)
                    Console.Write("    ");
            }

            public void DumpValue(int indent)
            {
                Indent(indent);
                Console.WriteLine("{0}", GetType().ToString());

                Indent(indent);
                Console.WriteLine("{");

                foreach (var field in GetType().GetFields(System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance))
                {
                    object value = field.GetValue(this);
                    Indent(indent + 1);
                    if (value is Node)
                    {
                        Console.WriteLine("{0}: ", field.Name);
                        ((Node)value).DumpValue(indent + 2);
                    }
                    else if (value is IEnumerable && !(value is String))
                    {
                        Console.WriteLine("{0}: [", field.Name);
                        var list = (IEnumerable)value;
                        foreach (var item in list)
                        {
                            if (item is Node)
                                ((Node)item).DumpValue(indent + 2);
                            else
                            {
                                Indent(indent + 2);
                                Console.WriteLine(item);
                            }
                        }
                        Indent(indent + 1);
                        Console.WriteLine("]");
                    }
                    else
                        Console.WriteLine("{0}: {1}", field.Name, value);
                }

                Indent(indent);
                Console.WriteLine("}");
            }

        } */

    }
