﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using AST;
namespace GPLexTutorial
{
   
    class Program
    {
        static void Main(string[] args)
        {
            var filename = args[0];
            var file = new FileStream(args[0], FileMode.Open);
            Scanner scanner = new Scanner(file);               
            Parser parser = new Parser(scanner);
            parser.Parse();
            Parser.root.dump(0);
            Scope scope = new Scope() ;
            Parser.root.ResolvedName(scope);
            Parser.root.TypeCheck();

            //AST.PackageDeclaration_Opt de = new AST.PackageDeclaration_Opt();
            //Console.Read();  

             StreamWriter st = new StreamWriter(filename + ".il");
            // StreamWriter st = new StreamWriter(filename + "111.txt");
            //st.WriteLine("a");
            Parser.root.gecode(st);
            st.Close();
            Console.Read();
          
            //st.WriteLine();
            /*      var program = new CompilationUnit(null, null, new List<TypeDeclaration>
              { new ClassDeclaration("HelloWorld",new List<Modifier>(), new List<MethodDeclaration>
              { new MethodDeclaration(new List<Modifier>(), new VoidType("void"),
              new List<FormalParameter>{new FormalParameter("args",
              new ArrayType(new NamedType("string")) ) }, "main",
              new List<BlockStatement>{new LocalVariableDeclarationstatement(
              new NamedType("int"),"x"),new AssignmentExpression(new VariableInitializer("x", 42))}) }) });


               program.DumpValue(1);
               Console.Read(); */

        }


    }

   
/*

    public abstract class TypeDeclaration : Node { }


    public class PackageDeclaration : Node { }
    public class ImportDeclarations : Node { }
    public class FormalParameter : Node
    {
        private string ident; //args
        private Type type; //string []
        public FormalParameter(string ident, Type type)
        {
            this.ident = ident;
            this.type = type;
        }


    }



    public class CompilationUnit : Node
    {
        private PackageDeclaration packageDeclaration;
        private ImportDeclarations importDeclaration;
        private List<TypeDeclaration> typeDeclarations;
        public CompilationUnit(PackageDeclaration packageDeclaration, ImportDeclarations importDeclaration, List<TypeDeclaration> typeDeclarations)
        {
            this.packageDeclaration = packageDeclaration;
            this.importDeclaration = importDeclaration;
            this.typeDeclarations = typeDeclarations;
        }
    };

    public enum Modifier { Public, Private }//public

    public class ClassDeclaration : TypeDeclaration
    {
       

    };
    public class NormalClassDeclaration : ClassDeclaration
    {
        private string identifier;//HelloWrold
        private List<Modifier> classModifier;
        private List<MethodDeclaration> methodDeclaration;
        // "class"?
        public NormalClassDeclaration(string identifier, List<Modifier> classModifier, List<MethodDeclaration> methodDeclaration)
        {
            this.identifier = identifier;
            this.classModifier = classModifier;
            this.methodDeclaration = methodDeclaration;
        }
    }
    public class BlockStatement : Statement
    {

    }

    public class MethodDeclaration : TypeDeclaration
    {
        private List<Modifier> methodModifier; //public
        private ReturnType returnType; //void
        private List<FormalParameter> formalParameters;
        private string methodName; //main
        private List<BlockStatement> body;
        public MethodDeclaration(List<Modifier> methodModifier, ReturnType returnType, List<FormalParameter> formalParameters, string methodName, List<BlockStatement> body)
        {
            this.methodModifier = methodModifier;
            this.returnType = returnType;
            this.formalParameters = formalParameters;
            this.methodName = methodName;
            this.body = body;
        }

    }

    //string [] arg
   





    public class LocalVariableDeclarationstatement : BlockStatement
    {
        private NamedType type; //int
        private string Identifier; //x
        public LocalVariableDeclarationstatement(NamedType type, string Identifier)
        {
            this.type = type;
            this.Identifier = Identifier;
        }
    }

    public class ExpressionStatement : BlockStatement
    {
      
    }
    public class AssignmentExpression : ExpressionStatement
    {
        private VariableInitializer variableinitializer;
        public AssignmentExpression(VariableInitializer variableinitializer)
        {
            this.variableinitializer = variableinitializer;
        }
    }
    public class VariableInitializer : Node
    {
        private string Expressionname; //x
        private int Literal; //42
        public VariableInitializer(string Expressionname, int Literal)
        {
            this.Expressionname = Expressionname;
            this.Literal = Literal;
        }
    }
    public class DecimalIntegerLiteral : Node
    {
        private int a;
        public DecimalIntegerLiteral(int a ) {
            this.a = a;
        }
    }
    
   */ 

}

