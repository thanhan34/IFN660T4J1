﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public class Scope
    {
        protected Scope parentScope = null;
        Dictionary<string, AST.IDeclaration> symbol_table = new Dictionary<string, AST.IDeclaration>();
        public Scope()
        {
           
           // symbol_table.Clear();
        }
       public IDeclaration ResolveHere(string symbol)
        {
            if (symbol_table.ContainsKey(symbol))
            {
                return symbol_table[symbol];
            }
            else
            {
                return null;
            }
        }
        public IDeclaration Resolve(string symbol)
        {
            IDeclaration local = ResolveHere(symbol);
            if (local != null)
            {
                return local;
            }
            else if (parentScope != null)
            {
                return parentScope.Resolve(symbol);
            }
            else
                return null;
        }
        public void AddSymbol(string name, IDeclaration declaration)
        {
            this.symbol_table.Add(name, declaration);
        }
    }
}
