﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace AST
{
    
    // week 8 Bai start
    public  class Statements : Node {
        Type type;
        
        public Type get_type()
        {
            return type;
        }
        public override void dump(int indent)
        {
           
        }
        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {
           
        }
    }
    
    public class ExpressionStatement : Statements
    {
        private Expression exp;
        public override void ResolvedName(Scope scope)
        {
            exp.ResolvedName(scope);
        }     
        public ExpressionStatement(Expression exp)
        {
            this.exp = exp;
        }

        public override void dump(int indent)
        {
            label(indent, "Statement:\n");
            exp.dump(indent + 1);
        }

        public override void TypeCheck()
        {
            exp.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            exp.gecode(st);
            st.WriteLine("pop");
        }
    }
    /*
    public class Block : Statements
    {
        private LocalVariableDeclarationstatement localVariableDeclarationstatement;
        private Statement stat;
         public override void ResolvedName(Scope scope)
         {
            localVariableDeclarationstatement.ResolvedName(scope);
             stat.ResolvedName(scope);
         }
        public Block(LocalVariableDeclarationstatement localVariableDeclarationstatement)
        {
            this.localVariableDeclarationstatement = localVariableDeclarationstatement;

        }
        public Block(Statement stat)
        {

            this.stat = stat;
        }
        public override void dump(int indent)
        {
            label(indent, "Block:\n");
            if (localVariableDeclarationstatement != null)
            {
                localVariableDeclarationstatement.dump(indent + 1);
            }
            else if (stat != null)
            {
                stat.dump(indent + 1);
            }
        }
        public override void TypeCheck()
        {
            if (localVariableDeclarationstatement != null)
            { localVariableDeclarationstatement.TypeCheck(); }
            if (stat != null)
            {
                stat.TypeCheck();
            }
        }
        public void gecode(StreamWriter st) {
            localVariableDeclarationstatement.gecode(st);
            stat.gecode(st);
        }
    }
    */

    public class LocalVariableDeclarationstatement : Statements, IDeclaration
    {
        static int LastLocal = 0;

        private NamedType type; //int
        private IdentifierExpression identifier; //x
        private int num;

        public override void ResolvedName(Scope scope)
        {
            type.ResolvedName(scope);
        }
        public LocalVariableDeclarationstatement(NamedType type, IdentifierExpression identifier)
        {
            num = LastLocal++;
            this.type = type;
            this.identifier = identifier;
            identifier.type = type;
        }
        public override void dump(int indent)
        {
            label(indent, "LocalVariableDeclarationstatement:\n");
            type.dump(indent + 1);
            label(indent+1,"{0}\n", identifier);
        }
        public NamedType get_namedtype()
        {
            return type;
        }
        public string get_name()
        {
            return identifier.get_name();
        }
        public override void TypeCheck()
        {
            type.TypeCheck();

        }

        public void gecode(StreamWriter st)
        {
            emit(st, ".locals init ([%d] %s %s)", num, type.get_name(), identifier.get_name());
        }
    }
    public class MethodBody : Statements
    {
        private List<Statements>  statements;

        public override void ResolvedName(Scope scope)
        {
            foreach (var stmt in statements)
                if (stmt is IDeclaration)
                {
                    IDeclaration decl = (IDeclaration)stmt;

                    scope.AddSymbol(decl.get_name(), decl); 
                }

            foreach (var stmt in statements)
                stmt.ResolvedName(scope);
        }  

        public MethodBody(List<Statements> statements)
        {         
            this.statements = statements;          
        }
        public override void dump(int indent)
        {
            label(indent,"Block");
            foreach (var a in statements)
            {
                a.dump(indent);
            }

        }
        public override void TypeCheck()
        {
            foreach (var a in statements)
            {
                a.TypeCheck(); 
            }
        }
        public void gecode(StreamWriter st)
        {
            foreach (var a in statements)
            {
                a.gecode(st);
            }
            
        }
    }
 
    public class MethodHeader : Statements
    {
        private MethodDeclarator methodDecalrator;
        private Result result;

        public string get_name()
        {
            return methodDecalrator.get_name();
        }
        public override void ResolvedName(Scope scope)
        {
            methodDecalrator.ResolvedName(scope);
            result.ResolvedName(scope);
        }
        public MethodHeader(Result result, MethodDeclarator methodDecalrator)
        {
            this.methodDecalrator = methodDecalrator;
            this.result = result;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodHeader:\n");
            methodDecalrator.dump(indent+1);
            result.dump(indent+1);
        }
        public override void TypeCheck()
        {
            methodDecalrator.TypeCheck();
            result.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            methodDecalrator.gecode(st);
            result.gecode(st);
        }
    }
    public class Dims : Statements
    {
        private char left;
        private char right;
        public override void ResolvedName(Scope scope)
        {
   
        }
        public Dims()
        { }
        public Dims(char left, char right)
        {
            this.left = left;
            this.right = right;
        }

        public override void dump(int indent)
        {
            label(indent, "Dims:\n");
        }
        public override void TypeCheck()
        {

        }
        public void gecode(StreamWriter st)
        {

        }
    }
   
  
}
