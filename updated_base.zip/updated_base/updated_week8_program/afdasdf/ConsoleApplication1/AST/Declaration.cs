﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace AST
{
    public interface IDeclaration
    {
        string get_name();
    }

    public class ImportDeclaration : Node
    {
        public ImportDeclaration()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ImportDeclaration\n");
        }
        public override void ResolvedName(Scope scope)
        {

        }
        public override void TypeCheck()
        {

        }
        public void gecode(StreamWriter st)
        {

        }
    }


    /*
    public class LocalVariableDeclaration : Node, IDeclaration
    {
        private UnannType unannType;
        private VariableDeclarator variableDeclartor;
        public LocalVariableDeclaration(UnannType unannType, VariableDeclarator variableDeclartor)
        {
            this.unannType = unannType;
            this.variableDeclartor = variableDeclartor;
        }
        public override void dump(int indent)
        {
            label(indent, "LocalVariableDeclaration\n");
            unannType.dump(indent + 1, "UnannType");
            variableDeclartor.dump(indent + 1, "VariableDeclarator");
        }
        public override void ResolvedName(Scope scope)
        {
            unannType.ResolvedName(scope);
            variableDeclartor.ResolvedName(scope);
        }
        public override void TypeCheck()
        {
            unannType.TypeCheck();
            variableDeclartor.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            unannType.gecode(st);
            variableDeclartor.gecode(st);
        }

    }

    public class VariableDeclarator : Node, IDeclaration
    {
        private Identifier identifier;
        public VariableDeclarator(Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent, "VariableDeclarator\n");
            identifier.dump(indent + 1, "Identifier");
        }
        public override void ResolvedName(Scope scope)
        {
            identifier.ResolvedName(scope);
        }
        public override void TypeCheck()
        {
            identifier.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            identifier.gecode(st);
        }
    }
    */


    public abstract class TypeDeclaration : Node
    {

    }

    public class NormalClassDeclaration : TypeDeclaration, IDeclaration
    {
        private ClassModifier classModifier;
        private Identifier identifier;//HelloWrold
        private TypeParameters_opt typeParameters_opt;
        private SuperClass_opt superClass_opt;
        private SuperInterfaces_opt superInterfaces_opt;
        private ClassBody classBody;

        public string get_name()
        {
            return identifier.ToString();
        }

        public void gecode(StreamWriter st)
        {
            classModifier.gecode(st);
            identifier.gecode(st);
            typeParameters_opt.gecode(st);
            superClass_opt.gecode(st);
            superInterfaces_opt.gecode(st);
            classBody.gecode(st);
        }
        public NormalClassDeclaration(ClassModifier classModifier, Identifier identifier, 
            TypeParameters_opt typeParameters_opt, SuperClass_opt superClass_opt, 
            SuperInterfaces_opt superInterfaces_opt, ClassBody classBody)
        {

            this.classModifier = classModifier;
            this.identifier = identifier;
            this.typeParameters_opt = typeParameters_opt;
            this.superClass_opt = superClass_opt;
            this.superInterfaces_opt = superInterfaces_opt;
            this.classBody = classBody;
        }
        public override void dump(int indent)
        {
            label(indent, "NormalClassDeclaration:\n");
            classModifier.dump(indent + 1);
            identifier.dump(indent + 1);
            typeParameters_opt.dump(indent + 1);
            superClass_opt.dump(indent + 1);
            superInterfaces_opt.dump(indent + 1);
            classBody.dump(indent + 1);
        }
        public override void ResolvedName(Scope scope)
        {
            classModifier.ResolvedName(scope);
            identifier.ResolvedName(scope);
            typeParameters_opt.ResolvedName(scope);
            superClass_opt.ResolvedName(scope);
            superInterfaces_opt.ResolvedName(scope);
            classBody.ResolvedName(scope);
        }
        public override void TypeCheck()
        {
            classModifier.TypeCheck();
            identifier.TypeCheck();
            typeParameters_opt.TypeCheck();
            superClass_opt.TypeCheck();
            superInterfaces_opt.TypeCheck();
            classBody.TypeCheck();
        }
    }
    public class MethodDeclarator : Node
    {
        private Identifier identifier;
        private FormalParameterList formalParameterList;
        // private Dims dims;

        public string get_name()
        {
            return identifier.get_name();
        }
        public MethodDeclarator(Identifier identifier, FormalParameterList formalParameterList)
        {
            this.identifier = identifier;
            this.formalParameterList = formalParameterList;

            // this.dims = dims;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodDeclarator:\n");
        }
        public override void ResolvedName(Scope scope)
        {
            identifier.ResolvedName(scope);
            formalParameterList.ResolvedName(scope);
        }
        public override void TypeCheck()
        {
            identifier.TypeCheck();
            formalParameterList.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            identifier.gecode(st);
            formalParameterList.gecode(st);
        }
    }

        public class MethodDeclaration : Node, IDeclaration
        {
            private MethodModifier methodModifier; //public   
            private MethodHeader methodHeader;
            private MethodBody methodBody;

        public string get_name()
        {
            return methodHeader.get_name();
        }

        public void gecode(StreamWriter st)
        {
            methodModifier.gecode(st);
            methodHeader.gecode(st);
            methodBody.gecode(st);
        }
        public MethodDeclaration(MethodModifier methodModifier, MethodHeader methodHeader, MethodBody methodBody)
            {
                this.methodModifier = methodModifier;
                this.methodHeader = methodHeader;
                this.methodBody = methodBody;
            }
            public override void dump(int indent)
            {
                label(indent, "MethodDeclaration:\n");
                methodModifier.dump(indent + 1);
                methodHeader.dump(indent + 1);
                methodBody.dump(indent + 1);
            }
            public override void ResolvedName(Scope scope)
            {
                methodModifier.ResolvedName(scope);
                methodHeader.ResolvedName(scope);
                methodBody.ResolvedName(scope);
            }
        public override void TypeCheck()
        {
            methodModifier.TypeCheck();
            methodHeader.TypeCheck();
            methodBody.TypeCheck();
        }
    }
        public class Identifier : Node
        {
            private string ident;

            public string get_name()
            {
                return ident;
            }

            public override void ResolvedName(Scope scope)
            {

            }
            public Identifier(string ident)
            {
                this.ident = ident;
            }
            public override void dump(int indent)
            {
                label(indent, "{0}\n", ident);

            }
        public override void TypeCheck()
        {

        }
        public  void gecode(StreamWriter st)
        {
            
        }
    }


        public class IDENT : Node
        {
            private string iDENT;
            public override void ResolvedName(Scope scope)
            {

            }
            public IDENT(string iDENT)
            {
                this.iDENT = iDENT;
            }
            public override void dump(int indent)
            {
                label(indent, "IDENT: {0}\n", iDENT);
            }
        public override void TypeCheck()
        {

        }
        public  void gecode(StreamWriter st)
        {
            
        }
    }
        //frank 10/04

        public class ClassBody : Node
        {
            private ClassBodyDeclaration classBodyDeclaration;
            public ClassBody(ClassBodyDeclaration classBodyDeclaration)
            {
                this.classBodyDeclaration = classBodyDeclaration;
            }
            public override void dump(int indent)
            {
                label(indent, "ClassBosy:\n");
                classBodyDeclaration.dump(indent + 1);
            }
            public override void ResolvedName(Scope scope)
            {
                classBodyDeclaration.ResolvedName(scope);
            }
        public override void TypeCheck()
        {
            classBodyDeclaration.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            classBodyDeclaration.gecode(st);
        }
    }


        public class ClassBodyDeclaration : Node
        {
            private MethodDeclaration methodDeclaration;
            public ClassBodyDeclaration(MethodDeclaration methodDeclaration)
            {
                this.methodDeclaration = methodDeclaration;
            }
            public override void dump(int indent)
            {
                label(indent, "ClassBodyDeclaration:\n");
                methodDeclaration.dump(indent + 1);
            }
            public override void ResolvedName(Scope scope)
            {
                methodDeclaration.ResolvedName(scope);
            }
        public override void TypeCheck()
        {
            methodDeclaration.TypeCheck();
        }
        public void gecode(StreamWriter st)
        {
            methodDeclaration.gecode(st);
        }
    }

    
}

    //frank 10/04

