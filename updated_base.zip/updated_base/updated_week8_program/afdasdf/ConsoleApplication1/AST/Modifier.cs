﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AST
{
    public abstract class Modifier: Node
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void TypeCheck()
        {

        }
        public abstract void gecode(StreamWriter st);
        
    }
    public class Public : Modifier
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "PublicModifier:\n");
        }
        public override void gecode(StreamWriter st)
        {
           
        }

    }
    public class Static : Modifier
    {
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "StaticModifier:\n");
        }
        public override void gecode(StreamWriter st)
        {
            
        }
    }
   
    public class ClassModifier : Modifier
    {
        private string Public;
        public ClassModifier(string Public)
        {
            this.Public = Public;
        }
        public override void ResolvedName(Scope scope)
        {

        }
        public override void dump(int indent)
        {
            label(indent, "{0}\n",Public);
        }
        public override void gecode(StreamWriter st)
        {
            
        }
    }
      public class MethodModifier : Modifier
     {
        private string Public;
        private string Static;
        public override void ResolvedName(Scope scope)
        {
            
        }
        public MethodModifier( string Public,  string Static)
         {
            this.Public = Public;
            this.Static = Static;
         }
       
        public override void dump(int indent)
         {
            label(indent, "MethodModifier: {0} {1}\n",Public,Static);
         }
        public override void gecode(StreamWriter st)
        {
           
        }
    }
     
}
