﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace AST
{
    public  class Type : Node {

        private string type_name;
        public bool Compatible(Type type)
        {
            return Equal(type);
        }
        public void gecode(StreamWriter st)
        {

        }
        //public abstract void gecode(StreamWriter st);

        public virtual bool Equal(Type type) {
            return true;
        }
        public override void dump(int indent)
        {
            
        }
        public string get_name()
        {
            return type_name;
        }
        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {

        }

    }
    public class Result : Type
    {
        /*public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "Result:\n");
        }
        public void gecode(StreamWriter st)
        {

        }
    }
    public class UnannType : Type
    {
        private UnannPrimitiveType unannPrimitiveType;
        private UnannReferenceType unannReferenceType;
        /* public override void ResolvedName()
         {
             unannPrimitiveType.ResolvedName();
             unannReferenceType.ResolvedName();
         }*/
        public void gecode(StreamWriter st)
        {
            if (unannPrimitiveType != null)
            { unannPrimitiveType.gecode(st); }
            if (unannReferenceType != null)
            { unannReferenceType.gecode(st); }
        }
        public UnannType(UnannPrimitiveType unannPrimitiveType)
        {
            this.unannPrimitiveType = unannPrimitiveType;
           
        }
        public UnannType(UnannReferenceType unannReferenceType)
        {
            
            this.unannReferenceType = unannReferenceType;
        }
        public override void dump(int indent)
        {
            label(indent, "UnannType:\n");
            if (unannPrimitiveType != null)
            {
                unannPrimitiveType.dump(indent + 1);
            }
            else if (unannReferenceType != null)
            {
                unannReferenceType.dump(indent + 1);
            }
        }
    }
    public class UnannPrimitiveType : Type
    {
        private NumericType numericType;
        private string boolean;
        /*public override void ResolvedName()
        {
            numericType.ResolvedName();
        }*/
        //boolean numeric
        public UnannPrimitiveType(NumericType numericType)
        {
            this.numericType = numericType;
        }
        public UnannPrimitiveType(string boolean)
        {
            this.boolean = boolean;
        }
        public override void dump(int indent)
        {
            numericType.dump(indent + 1, "numericType:\n");
            
        }
        public void gecode(StreamWriter st)
        {
            numericType.gecode(st);

        }

    }

    // week8 Bai
    public class NumericType : Type
    {
        private IntegralType inter;
        private FloatingPointType floatpoint;
       /* public override void ResolvedName()
        {
            inter.ResolvedName();
            floatpoint.ResolvedName();
        }*/
        public NumericType(IntegralType inter)
        {
            this.inter = inter;
        }
        public NumericType(FloatingPointType floatpoint)
        {
            this.floatpoint = floatpoint;
        }
        public override void dump(int indent)
        {
            label(indent, "NumericType:\n");
            if (inter != null)
            {
                inter.dump(indent);
            }
            else if (floatpoint != null)
            {
                floatpoint.dump(indent);
            }
        }
        public void gecode(StreamWriter st)
        {
            inter.gecode(st);
            floatpoint.gecode(st);
        }
    }

    public class ByteType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "ByteType\n");
        }
        public override bool Equal(Type type)
        {
            return (type is ByteType);
        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class ShortType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "ShortType\n");
            
        }
        public override bool Equal(Type type)
        {
            return (type is ShortType);
        }
    }

    public class LongType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "LongType\n");

        }
        public override bool Equal(Type type)
        {
            return (type is LongType);
        }
    }

    public class CharType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "CharType\n");

        }
        public override bool Equal(Type type)
        {
            return (type.GetType() is CharType);
        }
    }
    public class StringType : Type
    {
        /* public override void ResolvedName()
         {

         }*/
        public override void dump(int indent)
        {
            label(indent, "StringType\n");

        }
    }
    public class BoolType : Type
    {
        
        public override void dump(int indent)
        {
            label(indent, "BoolType\n");

        }
        public override bool Equal(Type type)
        {
            return (type is BoolType);
        }
    }
    public class InteType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "IntType\n");
        }
        public override bool Equal(Type type)
        {
            return (type is IntType);
        }
        public void gecode(StreamWriter st)
        {

        }
    }
    public class IntegralType : Type
    {
        public string inttype;
       /* public override void ResolvedName()
        {

        }*/
        public IntegralType(string inttype) {

            this.inttype = inttype;

        }
        public override void dump(int indent)
        {
            label(indent, "IntegralType : {0}\n", inttype);
        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class FloatingPointType : Type
    {
        private string floattype;
       /* public override void ResolvedName()
        {

        }*/
        public FloatingPointType(string floattype) {
            this.floattype = floattype;
        }
        public override void dump(int indent)
        {
            label(indent, "FloatingPointType : {0}\n", floattype);
        }
        public override bool Equal(Type type)
        {
            return (type is FloatingPointType);
        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class FloatType : Type
    {
        /*public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "FloatType\n");
        }
        public override bool Equal(Type type)
        {
            return (type is FloatType);
        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class DoubleType : Type
    {
       /* public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
        {
            label(indent, "DoubleType\n");
        }
        public override bool Equal(Type type)
        {
            return (type is DoubleType);
        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class UnannReferenceType : Type
    {
        private UnannArrayType unannArrayType;
        /*public override void ResolvedName()
        {
            unannArrayType.ResolvedName();
        }*/

        public UnannReferenceType(UnannArrayType unannArrayType)
        {
            this.unannArrayType = unannArrayType;
        }
        public override void dump(int indent)
        {
            label(indent, "UnannReferenceType:\n");
            unannArrayType.dump(indent+1);
        }
        public void gecode(StreamWriter st)
        {

        }
    }
    public class UnannArrayType : Type
    {
        private UnClassOrInterfaceType unClassOrInterfaceType;
        private Dims dims1;
       /* public override void ResolvedName()
        {
            unClassOrInterfaceType.ResolvedName();
            dims1.ResolvedName();
        }*/
        public UnannArrayType(UnClassOrInterfaceType unClassOrInterfaceType, Dims dims1)
        {
            this.unClassOrInterfaceType = unClassOrInterfaceType;
            this.dims1 = dims1;
          

        }
        public override void dump(int indent)
        {
            label(indent+1,"unannarraytype:\n");
            unClassOrInterfaceType.dump(indent+1);
            dims1.dump(indent+1);
        }
        public void gecode(StreamWriter st)
        {
            unClassOrInterfaceType.gecode(st);
            dims1.gecode(st);
        }
    }

    public class UnClassOrInterfaceType : Type
    {
        private UnClassType unClassType;
       /* public override void ResolvedName()
        {
            unClassType.ResolvedName();
        }*/
        public UnClassOrInterfaceType (UnClassType unClassType)
        {
            this.unClassType = unClassType;
        }
        public override void dump(int indent)
        {
            label(indent + 1, "UnClassOrInterfaceType:\n");
            unClassType.dump(indent+1);
        }
        public void gecode(StreamWriter st)
        {
            unClassType.gecode(st);
        }
    }

    public class UnClassType : Type
    {
        private string STRING;
       /* public override void ResolvedName()
        {

        }*/
        public UnClassType (string STRING)
        {
            this.STRING = STRING;
        }

        public override void dump(int indent)
        {
            label(indent + 1, "UnClassType : {0}\n", STRING);

        }
        public void gecode(StreamWriter st)
        {

        }
    }

    public class UnannTypeVariable : Type
    {
        private Identifier identifier;
        /*public override void ResolvedName()
        {

        }*/
        public UnannTypeVariable (Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent + 1, "UnannTypeVariable:\n");
        }
        public void gecode(StreamWriter st)
        {
            identifier.gecode(st);
        }
    }

      public class NamedType : Type
      {
        // private string typeName;
        string type;
        /*public override void ResolvedName()
        {

        }*/
        public NamedType(string type)
          {
              this.type = type;
          }
          public override void dump(int indent)
          {
              label(indent, "NamedType: {0}\n", type);
          }
        public void gecode(StreamWriter st)
        {

        }
        public Type get_type()
        {

            switch (type)
            {
                case "string": return new StringType();
                    break;

                case "int":
                    return new IntType();
                    break;
                case "char":
                    return new CharType();
                    break;
                case "boolean":
                    return new BoolType();
                    break;
                case "float":
                    return new FloatType();
                    break;
                default:
                    return null;
            }
        }
      }
      public class ArrayType : Type
      {
          private Type elementType;
        /*public override void ResolvedName()
        {

        }*/
        public ArrayType(Type elementType)
          {
              this.elementType = elementType;
          }
          public override void dump(int indent)
          {
              label(indent, "elementType:\n");
          }
        public void gecode(StreamWriter st)
        {
            elementType.gecode(st);
        }
    }


      public class ReturnType : Type
    {
        /*public override void ResolvedName()
        {

        }*/
        public override void dump(int indent)
          {
              label(indent, "ReturnType\n");
          }
        public void gecode(StreamWriter st)
        {

        }

    }
      public class VoidType : Result
      {
          
          public override void dump(int indent)
          {
              label(indent, "VoidType\n");
          }
        public void gecode(StreamWriter st)
        {

        }
    }

  
    
     public class IntType : Result
     {

         public override void dump(int indent)
         {
             label(indent, "IntType\n");
         }
        public void gecode(StreamWriter st)
        {

        }
    }
     

  
}
