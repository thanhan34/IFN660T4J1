﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public class CompilationUnit : Node
    {
        private PackageDeclaration_Opt packageDeclaration_Opt;
        private ImportDeclaration importDeclaration;
        private List<TypeDeclaration> typeDeclarations;
        public override void TypeCheck()
        {
        }
        public override void ResolvedName(Scope scope)
        {
            packageDeclaration_Opt.ResolvedName(scope);
            importDeclaration.ResolvedName(scope);
            foreach (var child in typeDeclarations)
            {
                child.ResolvedName(scope);
            }
        }
        public CompilationUnit(PackageDeclaration_Opt packageDeclaration_Opt, ImportDeclaration importDeclaration, List<TypeDeclaration> typeDeclarations)
        {
            this.packageDeclaration_Opt = packageDeclaration_Opt;
            this.importDeclaration = importDeclaration;
            this.typeDeclarations = typeDeclarations;
        }
        public override void dump(int indent)
        {
            label(indent, "CompilationUnit:\n");
            packageDeclaration_Opt.dump(indent+1);
            importDeclaration.dump(indent+1);
            
            foreach (var child in typeDeclarations)
                child.dump(indent+1);

           
        }
    }
}
