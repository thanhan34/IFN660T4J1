﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public abstract class Option : Node
    {
        public override void ResolvedName(Scope scope)
        {

        }
    }

    public class TypeParameters_opt : Option
    {
        public override void dump(int indent)
        {
            label(indent, "TypeParameters_opt:\n");
        }

        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class SuperClass_opt : Option
    {
        public override void dump(int indent)
        {
            label(indent, "Superclass_opt:\n");
        }

        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
    public class SuperInterfaces_opt : Option
    {
        public override void dump(int indent)
        {
            label(indent, "SuperInterfaces_opt:\n");
        }
        public override void ResolvedName(Scope scope)
        {
            
        }
        public override void TypeCheck()
        {
            throw new NotImplementedException();
        }
    }
}
