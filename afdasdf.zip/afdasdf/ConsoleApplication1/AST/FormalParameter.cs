﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    /*
    public class FormalParameter : Node
    {
        private string ident; //args
        private Type type; //string []
        public FormalParameter(string ident, Type type)
        {
            this.ident = ident;
            this.type = type;
        }
        public override void dump(int indent)
        {
            label(indent, "FormalParameter\n",ident);
            type.dump(indent + 1);
            
        }
    } */
    public class FormalParameterList : Node
    {
        private LastFormalParameter lastFormalParameter;
        public override void ResolvedName()
        {
            lastFormalParameter.ResolvedName();
        }
        public FormalParameterList(LastFormalParameter lastFormalParameter)
        {
            this.lastFormalParameter = lastFormalParameter;
        }
        public override void dump(int indent)
        {
            label(indent, "FormalParameterList");
        }
    }
    public class LastFormalParameter : Node
    {
        private UnannType unannType;
        private string ident;
        public override void ResolvedName()
        {
            unannType.ResolvedName();
        }
        public LastFormalParameter(UnannType unannType, string ident)
        {
            this.unannType = unannType;
            this.ident = ident;
        }
        public override void dump(int indent)
        {
            label(indent, "LastFormalParameter");
        }
    }

}
