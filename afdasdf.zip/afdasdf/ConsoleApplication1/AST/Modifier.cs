﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AST
{
    public abstract class Modifier: Node
    {
        public override void ResolvedName()
        {

        }
    }
    public class Public : Modifier
    {
        public override void ResolvedName()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "PublicModifier:\n");
        }
    }
    public class Static : Modifier
    {
        public override void ResolvedName()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "StaticModifier:\n");
        }
    }
   
    public class ClassModifier : Modifier
    {
        private string Public;
        public ClassModifier(string Public)
        {
            this.Public = Public;
        }
        public override void dump(int indent)
        {
            label(indent, "{0}\n",Public);
        }
    }
      public class MethodModifier : Modifier
     {
        private string Public;
        private string Static;
        public override void ResolvedName()
        {
            
        }
        public MethodModifier( string Public,  string Static)
         {
            this.Public = Public;
            this.Static = Static;
         }
    /*    public MethodModifier(Public Public)
        {
            this.Public = Public;
           
        }
        public MethodModifier(Static Static)
        {           
            this.Static = Static;
        }
        public MethodModifier()
        {

        } */
        public override void dump(int indent)
         {
            label(indent, "MethodModifier: {0} {1}\n",Public,Static);
         }
     }
     
}
