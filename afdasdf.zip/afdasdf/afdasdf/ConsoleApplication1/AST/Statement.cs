﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public abstract class Statement : Node { }

    public class MethodBody : Statement
    {
        private Block block;
        /*public override void ResolvedName() {
            blockStatement.ResolvedName();
        }  */

        public MethodBody(Block block)
        {
            this.block = block;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodBody");
        }
    }
 
    public class Block : Statement
    {
        private LocalVariableDeclaration localVariableDeclaration;

        public Block(LocalVariableDeclaration localVariableDeclaration)
        {
            this.localVariableDeclaration = localVariableDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "Block");
        }
    }
 
    public class LocalVariableDeclarationstatement : Statement
    {
        private NamedType type; //int
        private string identifier; //x
        public LocalVariableDeclarationstatement(NamedType type, string identifier)
        {
            this.type = type;
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent, "BlockStatement\n", identifier);
            type.dump(indent + 1);
        }
    }

    public class ExpressionStatement : Statement
    {
        public ExpressionStatement()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ExpressionStatement\n");
        }
    }
    /*
    public class AssignmentExpression : ExpressionStatement
    {
        private VariableInitializer variableinitializer;
        public AssignmentExpression(VariableInitializer variableinitializer)
        {
            this.variableinitializer = variableinitializer;
        }
        public override void dump(int indent)
        {
            label(indent, "AssignmentStatement\n");
            variableinitializer.dump(indent + 1);
        }
    }*/
    public class MethodHeader : Statement
    {
        private MethodDeclarator methodDecalrator;
        private Result result;
        public MethodHeader(Result result, MethodDeclarator methodDecalrator)
        {
            this.methodDecalrator = methodDecalrator;
            this.result = result;
        }
        public override void dump(int indent)
        {
            label(indent, "MethodHeader");
        }
    }
    public class Dims : Statement
    {
        private char left;
        private char right;
        public Dims()
        { }
        public Dims(char left, char right)
        {
            this.left = left;
            this.right = right;
        }

        public override void dump(int indent)
        {
            label(indent, "Dims");
        }
    }
  
}
