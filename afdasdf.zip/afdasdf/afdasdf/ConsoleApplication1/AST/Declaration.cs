﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST
{
    public abstract class Declaration : Node
    {

    }
    public class PackageDeclaration_Opt : Declaration
    {
        public PackageDeclaration_Opt()
        {
            
        }
        public override void dump(int indent)
        {
            label(indent, "PackageDeclaration_Opt\n");
        }
    }
    public class ImportDeclaration : Declaration
    {
        public ImportDeclaration()
        {

        }
        public override void dump(int indent)
        {
            label(indent, "ImportDeclaration\n");
        }
    }
    public abstract class TypeDeclaration : Declaration
    {
    }

    public class LocalVariableDeclaration : Declaration
    {
        private UnannType unannType;
        private VariableDeclarator variableDeclartor;
        public LocalVariableDeclaration(UnannType unannType, VariableDeclarator variableDeclartor)
            {
            this.unannType = unannType;
            this.variableDeclartor = variableDeclartor;
            }
        public override void dump(int indent)
        {
            label(indent, "LocalVariableDeclaration\n");
        }
    }
    public class VariableDeclarator : Declaration
    {
        private Identifier identifier;
        public VariableDeclarator(Identifier identifier)
        {
            this.identifier = identifier;
        }
        public override void dump(int indent)
        {
            label(indent, "VariableDeclarator\n");
        }
    }
    public class NormalClassDeclaration : TypeDeclaration
    {
        private ClassModifier classModifier;
        private Identifier identifier;//HelloWrold
        private TypeParameters_opt typeParameters_opt;
        private SuperClass_opt superClass_opt;
        private SuperInterfaces_opt superInterfaces_opt;
        private ClassBody classBody;
       // private List<Modifier> classModifier;   
        //private List<MethodDeclaration> methodDeclaration;  
        // "class"?
        public NormalClassDeclaration(ClassModifier classModifier, Identifier identifier, TypeParameters_opt typeParameters_opt, 
            SuperClass_opt superClass_opt, SuperInterfaces_opt superInterfaces_opt, ClassBody classBody)
        {
          
            this.classModifier = classModifier;
            this.identifier = identifier;
            this.typeParameters_opt = typeParameters_opt;
            this.superClass_opt = superClass_opt;
            this.superInterfaces_opt = superInterfaces_opt;
            this.classBody = classBody;
        }
        
        public override void dump(int indent)
        {
            label(indent, "NormalClassDeclaration\n", identifier);
            
            /*foreach (var child in classModifier)
                child.dump(indent + 1);
            foreach (var child in methodDeclaration)
                child.dump(indent + 1); */
        }
    }
    public class MethodDeclarator : Declaration
    {
        private Identifier identifier;
        private FormalParameterList formalParameterList;
        private Dims dims;
        public MethodDeclarator(Identifier identifier, FormalParameterList formalParameterList, Dims dims)
        {
            this.identifier = identifier;
            this.formalParameterList = formalParameterList;
            this.dims = dims;
        }
        public override void dump(int indent)
        {
            label(indent, "NormalClassDeclaration\n");
        }
    }
    public class MethodDeclaration : Declaration
    {      
        private MethodModifier methodModifier; //public   
        private MethodHeader methodHeader;
        private MethodBody methodBody;
        public MethodDeclaration(MethodModifier methodModifier, MethodHeader methodHeader, MethodBody methodBody)
        {
            this.methodModifier = methodModifier;
            this.methodHeader = methodHeader;
            this.methodBody = methodBody;
        }    
        public override void dump(int indent)
        {
            label(indent, "MethodDeclaration\n");         
            label(indent, "MethodHeader\n");
            label(indent, "MethodBody\n");
        }
    }  
    public class Identifier : Node
    {
        private IdentifierChars identifierChars;
        public Identifier(IdentifierChars identifierChars)
        {
            this.identifierChars = identifierChars;
        }
        public override void dump(int indent)
        {
            label(indent, "Identifier");
        }
    }
    public class IdentifierChars : Node
    {
        private JavaLetter javaLetter;
        public JavaLetterOrDigits javaLetterOrDigits;
        public IdentifierChars(JavaLetter javaLetter, JavaLetterOrDigits javaLetterOrDigits)
        {
            this.javaLetter = javaLetter;
            this.javaLetterOrDigits = javaLetterOrDigits;
        }
        
        public override void dump(int indent)
        {
            label(indent, "IdentifierChars");
        }
    }
    public class JavaLetter : Node
    {
        private IDENT iDENT;
        public JavaLetter(IDENT iDENT)
        {
            this.iDENT = iDENT;
        }
        public override void dump(int indent)
        {
            label(indent, "JavaLetter");
        }
    }
    public class JavaLetterOrDigits : Node
    {
        public override void dump(int indent)
        {
            label(indent, "JavaLetterOrDigits");
        }
    }
    public class IDENT : Node
    {
        private string iDENT;
        public IDENT(string iDENT)
        {
            this.iDENT = iDENT;
        }
        public override void dump(int indent)
        {
            label(indent, "IDENT {0}\n", iDENT);
        }
    }
    //frank 10/04

    public class ClassBody : Declaration
    {
        private ClassBodyDeclaration classBodyDeclaration;
        public ClassBody(ClassBodyDeclaration classBodyDeclaration)
        {
            this.classBodyDeclaration = classBodyDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "ClassBody");
        }
    }


    public class ClassBodyDeclaration : Declaration
    {
        private MethodDeclaration methodDeclaration;
        public ClassBodyDeclaration(MethodDeclaration methodDeclaration)
        {
            this.methodDeclaration = methodDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "ClassBodyDeclaration");
        }
     
    }
    public class ClassMemberDeclaration : Declaration
    {
        private MethodDeclaration methodDeclaration;
        public ClassMemberDeclaration(MethodDeclaration methodDeclaration)
        {
            this.methodDeclaration = methodDeclaration;
        }
        public override void dump(int indent)
        {
            label(indent, "ClassMemberDeclaration");
        }

    }
 

    //frank 10/04
}
