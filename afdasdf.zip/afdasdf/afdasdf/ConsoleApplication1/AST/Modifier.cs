﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AST
{
    public abstract class Modifier: Node
    {
    }
    public class Public : Modifier
    {
        public override void dump(int indent)
        {
            label(indent, "PublicModifier\n");
        }
    }
    public class Static : Modifier
    {
        public override void dump(int indent)
        {
            label(indent, "StaticModifier\n");
        }
    }
   
    public class ClassModifier : Modifier
    {
        private string Public;
        public ClassModifier(string Public)
        {
            this.Public = Public;
        }
        public override void dump(int indent)
        {
            label(indent, "Public");
        }
    }
      public class MethodModifier : Modifier
     {
        private string Public;
        private string Static;
       
        public MethodModifier( string Public,  string Static)
         {
            this.Public = Public;
            this.Static = Static;
         }
    /*    public MethodModifier(Public Public)
        {
            this.Public = Public;
           
        }
        public MethodModifier(Static Static)
        {           
            this.Static = Static;
        }
        public MethodModifier()
        {

        } */
        public override void dump(int indent)
         {
            label(indent, "MethodModifier");
         }
     }
     
}
