﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST_Test
{
    public abstract class Node
    {
        void Indent(int n)
        {
            for (int i = 0; i < n; i++)
                Console.Write("    ");
        }

        public void DumpValue(int indent)
        {
            Indent(indent);
            Console.WriteLine("{0}", GetType().ToString());

            Indent(indent);
            Console.WriteLine("{");

            foreach (var field in GetType().GetFields(System.Reflection.BindingFlags.NonPublic |
                                                                           System.Reflection.BindingFlags.Instance))
            {
                object value = field.GetValue(this);
                Indent(indent + 1);
                if (value is Node)
                {
                    Console.WriteLine("{0}:", field.Name);
                    ((Node)value).DumpValue(indent + 2);
                }
                else if (value is List<ClassDeclaration>)
                {

                }
                else
                    Console.WriteLine("{0}: {1}", field.Name, value);
            }

            Indent(indent);
            Console.WriteLine("}");
        }

    }



    public abstract class TypeDeclaration : Node{ }
    public class PackageDeclaration : Node { }
    public class ImportDeclarations : Node { }
    public class FormalParameter : Node { }
    public class CompilationUnit: Node
    {
        private PackageDeclaration packageDeclaration;
        private ImportDeclarations importDeclaration;
        private List<TypeDeclaration> typeDeclarations;
        public CompilationUnit(PackageDeclaration packageDeclaration, ImportDeclarations importDeclaration, List<TypeDeclaration > typeDeclarations)
        {
            this.packageDeclaration = packageDeclaration;
            this.importDeclaration = importDeclaration;
            this.typeDeclarations = typeDeclarations;
        }
    };
    

    public class ClassDeclaration : TypeDeclaration
    {
        private string identifier;//HelloWrold
        private List<string> class_modifier; //Public
        
        // "class"?
        public ClassDeclaration(string identifier, List<string> class_modifier)
        {
            this.identifier = identifier;
            this.class_modifier = class_modifier;
        }

    };
    public class MethodDeclaration : TypeDeclaration
    {
        private string method_modifier; //public
        private string void_type; //void
        private UnannArrayType unannArrayType;// string[]       
        private string identfier; //args
        public MethodDeclaration(string method_modifier, string void_type, UnannArrayType unannArrayType, string identfier)
        {
            this.method_modifier = method_modifier;
            this.void_type = void_type;
            this.unannArrayType = unannArrayType;
            this.identfier = identfier;
        }

    }

    public class UnannArrayType: FormalParameter
    {
        private string identifier;
        public UnannArrayType(string identifier)
        {
            this.identifier = identifier;
        }
    }
   /* public class UnannType : Node
    {
        
    } */

    public class BlockStatement : Node
    {
        private LocalVariableDeclarationstatement localVariableDeclarationstatement;
        private Expression expression;
        public BlockStatement(LocalVariableDeclarationstatement localVariableDeclarationstatement, Expression expression)
        {
            this.localVariableDeclarationstatement = localVariableDeclarationstatement;
            this.expression = expression;

        }

    }
    public class LocalVariableDeclarationstatement : Node
    {
        private string  NumericType; //int
        private string Identifier; //x
        public LocalVariableDeclarationstatement(string NumericType, string Identifier)
        {
            this.NumericType = NumericType;
            this.Identifier = Identifier;
        }
    }

    public class Expression : Node
    {
        private VariableInitializer variableinitializer;
        public Expression(VariableInitializer variableinitializer)
        {
            this.variableinitializer = variableinitializer;
        }
    }

    public class VariableInitializer : Node
    {
        private string Expressionname; //x
        private int Literal; //42
        public VariableInitializer(string Expressionname, int Literal)
        {
            this.Expressionname = Expressionname;
            this.Literal = Literal;
        }
    }

    

   



}
