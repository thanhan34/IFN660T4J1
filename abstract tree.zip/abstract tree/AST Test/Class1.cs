﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST_Test
{
    public abstract class Node
    {
        void Indent(int n)
        {
            for (int i = 0; i < n; i++)
                Console.Write("    ");
        }

        public void DumpValue(int indent)
        {
            Indent(indent);
            Console.WriteLine("{0}", GetType().ToString());

            Indent(indent);
            Console.WriteLine("{");

            foreach (var field in GetType().GetFields(System.Reflection.BindingFlags.NonPublic |
                                                                           System.Reflection.BindingFlags.Instance))
            {
                object value = field.GetValue(this);
                Indent(indent + 1);
                if (value is Node)
                {
                    Console.WriteLine("{0}:", field.Name);
                    ((Node)value).DumpValue(indent + 2);
                }
                else if (value is List<ClassDeclaration>)
                {

                }
                else
                    Console.WriteLine("{0}: {1}", field.Name, value);
            }

            Indent(indent);
            Console.WriteLine("}");
        }

    }



    public abstract class TypeDeclaration : Node{ }
    public abstract class Statement : Node { }
    public abstract class Type : Node { }
    public class PackageDeclaration : Node { }
    public class ImportDeclarations : Node { }
    public class FormalParameter : Node
    {
        private string ident; //args
        private Type type; //string []
        public FormalParameter(string ident, Type type)
        {
            this.ident = ident;
            this.type = type;
        }


    }



    public class CompilationUnit: Node
    {
        private PackageDeclaration packageDeclaration;
        private ImportDeclarations importDeclaration;
        private List<TypeDeclaration> typeDeclarations;
        public CompilationUnit(PackageDeclaration packageDeclaration, ImportDeclarations importDeclaration, List<TypeDeclaration > typeDeclarations)
        {
            this.packageDeclaration = packageDeclaration;
            this.importDeclaration = importDeclaration;
            this.typeDeclarations = typeDeclarations;
        }
    };
    
    public enum Modifier {  Public, Private}//public

    public class ClassDeclaration : TypeDeclaration
    {
        private string identifier;//HelloWrold
        private List<Modifier> classModifier;
        private List<MethodDeclaration> methodDeclaration;
        // "class"?
        public ClassDeclaration(string identifier, List<Modifier> classModifier, List<MethodDeclaration> methodDeclaration )
        {
            this.identifier = identifier;
            this.classModifier = classModifier;
            this.methodDeclaration = methodDeclaration;
        }

    };
  
    public class MethodDeclaration : TypeDeclaration
    {
        private List<Modifier> methodModifier; //public
        private Type returnType; //void
        private List<FormalParameter> formalParameters; 
        private string methodName; //main
        private List<Statement> body;
        public MethodDeclaration(List<Modifier> methodModifier, Type returnType, List<FormalParameter> formalParameters, string methodName, List<Statement> body)
        {
            this.methodModifier = methodModifier;
            this.returnType = returnType;
            this.formalParameters = formalParameters;
            this.methodName = methodName;
            this.body = body;
        }

    }

    //string [] arg
    public class NamedType : Type
    {
        private string typeName;
 
        public NamedType (string typeName)
        {
            this.typeName = typeName;
        }
    }
    public class ArrayType: Type
    {
        private Type elementType;
        
        public ArrayType(Type elementType)
        {
            this.elementType = elementType;
        }
    }
   
  

    
  
    public class LocalVariableDeclarationstatement : Statement
    {
        private Type type; //int
        private string Identifier; //x
        public LocalVariableDeclarationstatement(Type type, string Identifier)
        {
            this.type = type;
            this.Identifier = Identifier;
        }
    }

    public class ExpressionStatement : Statement
    {
        private VariableInitializer variableinitializer;
        public ExpressionStatement(VariableInitializer variableinitializer)
        {
            this.variableinitializer = variableinitializer;
        }
    }

    public class VariableInitializer : Node
    {
        private string Expressionname; //x
        private int Literal; //42
        public VariableInitializer(string Expressionname, int Literal)
        {
            this.Expressionname = Expressionname;
            this.Literal = Literal;
        }
    }

    

   



}
