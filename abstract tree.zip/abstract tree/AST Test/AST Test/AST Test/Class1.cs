﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST_Test
{
    public abstract class Node
    {
        void Indent(int n)
        {
            for (int i = 0; i < n; i++)
                Console.Write("    ");
        }

        public void DumpValue(int indent)
        {
            Indent(indent);
            Console.WriteLine("{0}", GetType().ToString());

            Indent(indent);
            Console.WriteLine("{");

            foreach (var field in GetType().GetFields(System.Reflection.BindingFlags.NonPublic |
                                                                           System.Reflection.BindingFlags.Instance))
            {
                object value = field.GetValue(this);
                Indent(indent + 1);
                if (value is Node)
                {
                    Console.WriteLine("{0}:", field.Name);
                    ((Node)value).DumpValue(indent + 2);
                }
                else if (value is List<ClassDeclaration>)
                {

                }
                else
                    Console.WriteLine("{0}: {1}", field.Name, value);
            }

            Indent(indent);
            Console.WriteLine("}");
        }

    }



    public abstract class TypeDeclaration : Node{ }
    public class PackageDeclaration : Node { }
    public class ImportDeclarations : Node { }
    public class CompilationUnit: Node
    {
        private PackageDeclaration packageDeclaration;
        private ImportDeclarations importDeclaration;
        private List<TypeDeclaration> typeDeclarations;
        public CompilationUnit(PackageDeclaration packageDeclaration, ImportDeclarations importDeclaration, List<TypeDeclaration > typeDeclarations)
        {
            this.packageDeclaration = packageDeclaration;
            this.importDeclaration = importDeclaration;
            this.typeDeclarations = typeDeclarations;
        }
    };
    public class ClassDeclaration : TypeDeclaration
    {
        private string className;
        public ClassDeclaration(string name)
        {
            this.className = name;
        }

    };
}
