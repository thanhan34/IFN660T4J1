﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST_Test
{
    class Program
    {
        static void Main(string[] args)
        {

            var program = new CompilationUnit(null,null, new List<TypeDeclaration> { new ClassDeclaration() });
            program.DumpValue(0);
        }
    }
}
