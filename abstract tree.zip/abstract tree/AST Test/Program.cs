﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AST_Test
{
    class Program
    {
        static void Main(string[] args)
        {

            var program = new CompilationUnit(null,null, new List<TypeDeclaration> { new ClassDeclaration("HelloWorld",new List<Modifier>(), new List<MethodDeclaration> { new MethodDeclaration(new List<Modifier>(), new NamedType("void"), new List<FormalParameter>{new FormalParameter("args", new ArrayType(new NamedType("string")) ) }, "main", new List<Statement>{new LocalVariableDeclarationstatement(new NamedType("int"),"x"),new ExpressionStatement(new VariableInitializer("x", 42))}) }) });
            //ClassDeclaration(string identifier, List<Modifier> classModifier, List<MethodDeclaration> methodDeclaration )// new ArrayType(new NamedType("String");
            //MethodDeclaration(List<Modifier> methodModifier, Type returnType, List<FormalParameter> formalParameters, string methodName, List<Statement> body)
            program.DumpValue(1);
            Console.Read();
        }
    }
}
